class FailedApi(Exception):
	pass
class HttpsError(Exception):
	pass
class another(Exception):
	pass
		
		